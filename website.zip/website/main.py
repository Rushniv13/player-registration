from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# Store all registered players
players_list = []

# Login credentials
ADMIN_USERNAME = "rushniv"
ADMIN_PASSWORD = "barcelona345"


# Login page
@app.route("/", methods=["GET", "POST"])
def login():
    error = ""
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
            return redirect(url_for("menu"))
        else:
            error = "Access denied. Invalid credentials."
    return render_template("login.html", error=error)


# Main menu
@app.route("/menu")
def menu():
    return render_template("menu.html")


# Show players
@app.route("/players")
def players():
    sorted_players = sorted(players_list,
                            key=lambda p: int(p.split("ID ")[1].rstrip(")")))
    return render_template("players.html", players=sorted_players)


# Register a player
@app.route("/register", methods=["GET", "POST"])
def register():
    message = ""
    if request.method == "POST":
        user_id = request.form["user_id"]
        username = request.form["username"]
        for player in players_list:
            if f"ID {user_id}" in player:
                message = "ID already exists!"
                return render_template("register.html", message=message)
        players_list.append(f"{username} (ID {user_id})")
        return redirect(url_for("players"))
    return render_template("register.html", message=message)


# Remove a player
@app.route("/remove", methods=["GET", "POST"])
def remove():
    message = ""
    if request.method == "POST":
        id_remove = request.form["id_remove"]
        found = False
        for player in players_list:
            if f"ID {id_remove}" in player:
                players_list.remove(player)
                found = True
                message = f"Player with ID {id_remove} removed."
                break
        if not found:
            message = "No player found with that ID."
    return render_template("remove.html", message=message)


if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000, debug=True)
